# UniGrid Crawler — Setup Guide

This adds a manually-triggered crawler to your admin panel that:

1. Pulls **universities + bachelor's/associate programs** from YÖK Atlas's public JSON API (structural data: names, faculty, degree type, language, duration, quotas).
2. Runs **per-university fee adapters** to fill in tuition amounts (one working example included: Bilkent).
3. Tracks each run in a `crawl_jobs` table so the admin panel can show live progress and history.

## What this does NOT do (read before running)

- **No master's/doctorate coverage.** YÖK Atlas's `tercih-kılavuz` (central placement guide) only lists LISANS (bachelor) and ÖNLİSANS (associate) programs — that's the exam-based admission system it exists for. Graduate programs aren't centrally listed anywhere equivalent; you'll need to add those manually or write a separate source.
- **Fees are opt-in per university.** YÖK Atlas no longer publishes actual TRY/USD tuition figures (only a scholarship-tier label like "Ücretli" / "%50 İndirimli" for foundation universities). Real fee numbers only exist on each university's own site, and every site formats them differently — so fees are only populated for universities that have an adapter registered in `feeAdapters/index.ts`. Everyone else keeps whatever fee data you enter manually.
- **No EN/FA/AR translations.** YÖK Atlas is Turkish-only. On first creation, new universities/programs get the Turkish name copied into all four language fields as a placeholder — go translate them in the admin panel. **The crawler never overwrites `name_en`/`name_fa`/`name_ar`/descriptions on existing rows** on later runs, specifically so it's safe to re-run without clobbering your edits.
- **This is unofficial, reverse-engineered API usage.** The endpoints are the same ones YÖK Atlas's own website calls (verified via the open-source `yokatlas-py` wrapper), not a documented public API. There's no published rate limit or terms of use for this specific API; the crawler adds a small delay between paginated requests and runs manually (not on a schedule) to stay a light, occasional caller rather than a high-volume scraper. Consider reaching out to YÖK if you plan to run this at real scale/frequency.
- **University fee pages will drift.** Adapters are just parsing a specific page's current wording — if a university redesigns their site or rewords the fee line, that one adapter will start returning `null` (visible in job errors) rather than silently writing wrong data, but it will need a small update.

## 1. Apply the files

Copy this folder's contents into your repo at matching paths, overwriting:

- `lib/db/src/schema/crawl_jobs.ts` — new
- `lib/db/src/schema/index.ts` — patched (adds crawl_jobs export)
- `lib/db/src/schema/universities.ts` — patched (adds nullable `yok_universite_id` column)
- `artifacts/api-server/src/lib/yokatlas.ts` — new
- `artifacts/api-server/src/lib/feeAdapters/*` — new
- `artifacts/api-server/src/lib/crawler.ts` — new
- `artifacts/api-server/src/routes/admin/crawler.ts` — new
- `artifacts/api-server/src/routes/admin/index.ts` — patched (registers the new router)
- `artifacts/university-explorer/src/admin/api.ts` — patched (adds `adminApi.crawler`)
- `artifacts/university-explorer/src/admin/pages/Crawler.tsx` — new
- `artifacts/university-explorer/src/admin/AdminLayout.tsx` — patched (adds nav item)
- `artifacts/university-explorer/src/App.tsx` — patched (adds `/admin/crawler` route)

## 2. Push the schema change

```bash
pnpm --filter @workspace/db run push
```

This adds the `crawl_jobs` table and the `yok_universite_id` column to `universities`.

## 3. Typecheck & build

```bash
pnpm run typecheck
pnpm run build
```

## 4. Run it

Start the app, sign in as an admin, go to **Admin → Crawler**, click **Run Crawler**. The page polls every 2s while a job is running and shows a running tally of universities/faculties/programs touched, plus any per-item errors (a broken fee adapter or one university's data being briefly unavailable won't stop the whole run).

## Adding another university's fee adapter

1. Copy `artifacts/api-server/src/lib/feeAdapters/bilkent.ts` to a new file.
2. Point `SOURCE_URL` at that university's real fee page, and rewrite the parsing logic for how *that* page states its numbers (flat page text like Bilkent's, or a table — whatever it actually is). Fetch the real page yourself first and look at the actual wording before writing the regex/parsing; don't guess.
3. Set `matchName` to a distinctive substring of the university's Turkish name (as it appears in YÖK Atlas) so the crawler knows which DB rows to apply it to.
4. Register it in `feeAdapters/index.ts`.
5. Return `null` from `fetchFee()` (rather than throwing or guessing) if the page structure doesn't match what you expected — the crawler logs that as a per-item error and moves on.

## Extending beyond YÖK Atlas structural data

If you want photos, richer descriptions, or campus info per university, that's a good candidate for a second, separate crawl source (also triggered from the same Crawler page) rather than stretching the YÖK importer — keep the "structural facts" and "editorial content" concerns separate so one messy site's HTML can't break the reliable part of your data pipeline.
