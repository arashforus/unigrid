import type { UniversityFeeAdapter } from "./types";
import { bilkentFeeAdapter } from "./bilkent";

// Add one entry per university you want automated fee updates for.
// Universities not listed here simply won't get their tuition_fees
// touched by the crawler — keep editing those manually in the admin panel
// until you write an adapter for them.
export const feeAdapters: UniversityFeeAdapter[] = [bilkentFeeAdapter];
