// Every Turkish university publishes tuition fees differently: some as a
// flat annual figure for the whole university, some as a per-program table,
// some only as a PDF. There is no way to scrape this generically and
// reliably — so fees are handled as small, explicit, per-university
// adapters instead of one "universal" scraper.
//
// To add a university: copy an existing adapter file, point it at the
// right page, and register it in ./index.ts. Re-running the crawler is
// always safe — adapters only ever upsert a (program_id, academic_year)
// tuition_fees row, never delete.

export type FeeResult = {
  /** Applies the same fee to every active program at this university. */
  scope: "all_programs";
  academic_year: string; // e.g. "2026-2027"
  domestic_fee: number | null;
  international_fee: number | null;
  currency: "USD" | "EUR" | "TRY";
  source_url: string;
};

export interface UniversityFeeAdapter {
  /** Human-readable id, used in job stats/logs. */
  id: string;
  /**
   * Case-insensitive substring matched against the university's Turkish
   * name (as returned by YÖK Atlas) to find which DB row this applies to.
   */
  matchName: string;
  /** Fetches and parses the current fee(s). Return null if parsing fails
   *  (e.g. the page changed) rather than throwing, so one broken adapter
   *  doesn't fail the whole crawl. */
  fetchFee(): Promise<FeeResult | null>;
}
