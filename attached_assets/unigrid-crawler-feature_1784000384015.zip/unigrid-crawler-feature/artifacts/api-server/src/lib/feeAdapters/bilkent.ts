import type { UniversityFeeAdapter, FeeResult } from "./types";

const SOURCE_URL = "https://w3.bilkent.edu.tr/bilkent/international-and-other-students-tuition-fees/";

function stripHtml(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Bilkent publishes one flat annual fee for the whole university (all
 * bachelor/master/doctorate programs), tiered by the year the student was
 * admitted, e.g.:
 *   "For students admitted in 2026 is 18,400 USD"
 * We take the tier for the *current* admission year as the headline
 * international fee. Bilkent doesn't state a domestic fee on this page,
 * so domestic_fee is left null rather than guessed.
 */
export const bilkentFeeAdapter: UniversityFeeAdapter = {
  id: "bilkent",
  matchName: "bilkent",

  async fetchFee(): Promise<FeeResult | null> {
    const res = await fetch(SOURCE_URL, {
      headers: { "User-Agent": "UniGrid-Crawler/1.0 (+https://your-domain.example)" },
    });
    if (!res.ok) return null;

    const text = stripHtml(await res.text());

    const yearMatch = text.match(/(\d{4})\s*[–-]\s*(\d{4})\s*academic year/i);
    const academicYear = yearMatch ? `${yearMatch[1]}-${yearMatch[2]}` : null;

    // Collect every "admitted in/before <year> is <amount> USD" tier and
    // take the highest admission year (== current intake's fee).
    const tierRe = /admitted (?:in|before) (\d{4}) is ([\d,]+)\s*USD/gi;
    let best: { year: number; amount: number } | null = null;
    let m: RegExpExecArray | null;
    while ((m = tierRe.exec(text)) !== null) {
      const year = Number(m[1]);
      const amount = Number(m[2].replace(/,/g, ""));
      if (!best || year > best.year) best = { year, amount };
    }

    if (!academicYear || !best) return null;

    return {
      scope: "all_programs",
      academic_year: academicYear,
      domestic_fee: null,
      international_fee: best.amount,
      currency: "USD",
      source_url: SOURCE_URL,
    };
  },
};
