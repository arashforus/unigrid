export * from "./universities";
export * from "./faculties";
export * from "./programs";
export * from "./tuition_fees";
export * from "./inquiries";
export * from "./users";
export * from "./settings";
export * from "./crawl_jobs";
